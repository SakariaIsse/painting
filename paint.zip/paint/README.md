# Python painting Application GUI

A simple painting App gui

## Description

This application uses to paint or to draw your Art

## The video link:

https://youtu.be/PW7EHAiQ0Qg

## Running the application

python paint.py

## Prerequisites

[Python](https://www.python.org/)

[Tkinter](https://docs.python.org/3/library/tkinter.html)